package com.optum.ecap;

public class EcapException extends Exception {

	/**
	 * 
	 */
	private static final long serialVersionUID = 1L;

}
