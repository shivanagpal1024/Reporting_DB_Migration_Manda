package com.optum.ecap.kafka;

import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.producer.Callback;
import org.apache.kafka.clients.producer.KafkaProducer;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.clients.producer.ProducerRecord;
import org.apache.kafka.clients.producer.RecordMetadata;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringSerializer;
import io.confluent.kafka.serializers.KafkaAvroSerializer;

import com.optum.ecap.EcapEvent;
import com.optum.ecap.EcapException;

/**
 * @author rpackar
 *
 */
public class EcapKafkaPublisher {

	public EcapKafkaPublisher() throws EcapException {
		getKafkaProducer();
	}

	private Properties kafkaProperties = null;
	private Properties getKafkaProperties() {
		synchronized (this) {
//			String setting = DataAccess.getSetting("my settings key");
			if (kafkaProperties == null) {
				kafkaProperties = new Properties();
				kafkaProperties.put("kafka.bootstrap.server", "kaas-test-ctc-a.optum.com:443");
				kafkaProperties.put("kafka.schema.registry.url", "http://cp-schema-registry-data-exts-platform-dev.ocp-ctc-core-nonprod.optum.com");
				kafkaProperties.put("kafka.trustore.location", "/shared/cics/java_runtime/user_certs/ecap/ecap.optum.com.keystore.jks");
				kafkaProperties.put("kafka.trustore.password", "");
				kafkaProperties.put("kafka.keystore.location", "/shared/cics/java_runtime/user_certs/ecap/kaas-trustore.jks");
				kafkaProperties.put("kafka.keystore.password", "");
				kafkaProperties.put("kafka.data.event.topic", "kaas.ecap.ctc.cmd.dataevent.v1");
				kafkaProperties.put("kafka.business.event.topic", "kaas.ecap.ctc.cmd.businessevent.v1");
/*
				Connection connection = null;
				try {
				InitialContext ctx = new InitialContext();
			    	DataSource ds = (DataSource)ctx.lookup("java:/jboss/datasources/ggmap");
			    	connection = ds.getConnection();	
			    	PreparedStatement p = connection.prepareStatement("select * from settings_tbl where set_nm like 'kafka.%' ");		
			    	ResultSet r = p.executeQuery();
			    	while (r.next()) {
		LOGGER.log(Level.INFO, "kafkaStream settings " + r.getString("set_nm") );
		kafkaProperties.put(r.getString("set_nm"), r.getString("set_val"));
					}
			    	r.close();
					p.close();
					
				}catch(Exception e) {
					e.printStackTrace(System.err);
				}finally {
					try { connection.close(); } catch (Exception e) { e.printStackTrace(System.err); }
				}
*/
			}
		}
		return kafkaProperties;
	}
	private String getKafkaProperties(String key) {
		synchronized (this) {
			if (kafkaProperties == null) {
				getKafkaProperties();
			}
		}
		return (String)getKafkaProperties().get(key);
	}
	
	 private KafkaProducer<String, EcapEvent> kafkaProducer = null;
	 private KafkaProducer<String, EcapEvent> getKafkaProducer() {
		 if (kafkaProducer == null) {
			 Properties kafkaProps = new Properties();
			 kafkaProps.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG, getKafkaProperties("kafka.bootstrap.server") );
	        kafkaProps.put(ProducerConfig.KEY_SERIALIZER_CLASS_CONFIG, StringSerializer.class.getName() );
	        kafkaProps.put(ProducerConfig.VALUE_SERIALIZER_CLASS_CONFIG, KafkaAvroSerializer.class.getName() );
	        kafkaProps.put(ProducerConfig.ACKS_CONFIG, "1");
	        kafkaProps.put(ProducerConfig.RETRIES_CONFIG, "10");
	        kafkaProps.put("schema.registry.url", getKafkaProperties("kafka.schema.registry.url"));
	        kafkaProps.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG, "SSL" );
	        kafkaProps.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG, getKafkaProperties("kafka.trustore.location"));
	        kafkaProps.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG, getKafkaProperties("kafka.trustore.password") );
	        kafkaProps.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG, getKafkaProperties("kafka.keystore.location"));
	        kafkaProps.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG, getKafkaProperties("kafka.keystore.password") );
	        Thread.currentThread().setContextClassLoader(null);
	        kafkaProducer = new KafkaProducer<>(kafkaProps);	
		 } 
		return kafkaProducer;
	 }
	
	 private String getKafkaTopicType(String topicType) {
		 if ("D".equals(topicType)) return getKafkaProperties("kafka.data.event.topic");
		 return getKafkaProperties("kafka.business.event.topic");
	 }
	 
	 
	 private void kafkaStream(EcapEvent event, String topicType) {
		try {
//			String key = (String)event.getClaimSubmitter().getSubmitterId();
			//System.out.println("String key = (String)event.getClaimSubmitter().getSubmitterId();"+key);

			ProducerRecord<String, EcapEvent> record = new ProducerRecord<>(getKafkaTopicType(topicType), null, event);
			getKafkaProducer().send(record, new Callback()	{
                @Override
                public void onCompletion(RecordMetadata rm, Exception excptn) {
                    if (excptn != null) {
                    	excptn.printStackTrace(System.err);
                    } else {
//                    	System.out.println("Successfully sent record [" + record + "]to topic[" + rm.topic() + "] partition[" + rm.partition() + "] offset[" + rm.offset() + "]");
                    }
                }
    		});
    		getKafkaProducer().flush();
//    		closeKafkaStream();
//    		setKafkaProducer(null);
		} 
		catch(Exception e) {
    		e.printStackTrace(System.err);	
		}
	 }
	
  /**
   * Transmits an event to Kafka TOPIC
   * @param string The cobol copybook that defines the message to be sent to Kafka.  
   * @throws EcapException Refer to message payload of exception
   * @returns int 0 (Success), 4 (Warning), 8 (ERROR), 12 (SEVERE). Refer to System.log
   */
	public byte[] process(String copyBook, byte[] linkage) throws EcapException {
		System.out.println("copyBook = " + copyBook);
		byte[] returnBytes;
		returnBytes = "0".getBytes();
		String dataFromCobol = new String(linkage);
		EcapEvent e = new EcapEvent();
		/*
		 * dataFromCobol is a string of data, convert it into EcapEvent (avro schma object)
		 * send to kafka
		 */
		kafkaStream(e,dataFromCobol.substring(1,2));
		return returnBytes;
	}

	public void destroy() {
		getKafkaProducer().close();
	}

}
