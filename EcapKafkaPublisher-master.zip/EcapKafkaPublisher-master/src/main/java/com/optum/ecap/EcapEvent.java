package com.optum.ecap;

public class EcapEvent {

}
