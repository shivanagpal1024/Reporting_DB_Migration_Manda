package test.java;

public class runEcapKafkaConnection {

	public static void main(String[] args) {
		
	}

}
