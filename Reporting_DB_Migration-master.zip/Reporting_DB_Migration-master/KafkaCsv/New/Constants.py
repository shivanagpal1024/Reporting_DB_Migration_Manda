db2_database = "db2_database"
db2_username = "db2_username"
db2_password = "db2_password"
db2_host = "db2_host"
source_file_name_path = "source_file_name_path"
topic = "topic"
csv_file_name = 'CsvFileNames.txt'
key_and_value_schema_dict = {
    "rpt_audit": ["rpt_audit.avsc", "rpt_audit_key.avsc"]
}
topic_map = {
    "rpt_audit" : "kaas.alpha.ecap.rpt_audit.test"
}
bootstrap_server = "bootstrap.servers"
security_protocol = "security.protocol"
certificate_location = "ssl.certificate.location"
key_location = "ssl.key.location"
ca_location = "ssl.ca.location"
schema_registry = "schema.registry.url"
on_delivery = "on_delivery"