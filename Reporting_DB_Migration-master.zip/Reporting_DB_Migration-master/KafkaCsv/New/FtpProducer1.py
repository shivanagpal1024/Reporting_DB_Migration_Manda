import logging
import sys
from ftplib import error_perm
from KafkaCsv.New.configRead import ConfigRead
from KafkaCsv.New.ftpConn import FtpConn
from KafkaCsv.New.myAvroProducer import MyAvroProducer
from KafkaCsv.New import Constants as con
from requests.exceptions import ConnectionError

log = logging.getLogger('root')
FORMAT = "[%(levelname)s: %(filename)s:%(lineno)s - %(funcName)20s() ] %(message)s"
logging.basicConfig(format=FORMAT)
log.setLevel(logging.DEBUG)

avro_default_values = None
producer_obj = None

remap = {
    ord('\r'): None,
    ord('\n'): None,
    ord('\\'): r'\\',
}

counter = 1


def delivery_report(err, msg):
    global counter
    """ Called once for each message produced to indicate delivery result.
        Triggered by poll() or flush(). """
    if err is not None:
        log.info('Message delivery failed: %s counter=%s', err, counter)
    else:
        log.info('Message delivered to %s [%s] counter=%s', msg.topic(), msg.partition(), counter)
    counter += 1


def send():

    global producer_obj, avro_default_values
    log.info("reading configuration file")
    config_dict = ConfigRead("kafka_config.properties").get_config_dict()
    log.info("configuration file read successfully config_size=%s", len(config_dict))

    log.info("creating ftp connection")
    ftp_conn_obj = FtpConn(config_dict)
    log.info("connection created")

    log.info("creating setup for producer")
    avro_config = {
        con.bootstrap_server: config_dict[con.bootstrap_server],
        con.security_protocol: config_dict[con.security_protocol],
        con.key_location: config_dict[con.key_location],
        con.certificate_location: config_dict[con.certificate_location],
        con.schema_registry: config_dict[con.schema_registry],
        con.ca_location: config_dict[con.ca_location]
    }
    producer_obj = MyAvroProducer(avro_config)
    log.info("creating setup for producer")

    log.info("retrieving files")
    file_name = con.csv_file_name

    def send_lines_to_kafka(line):
        key, value = producer_obj.get_avro_json(csv_row_unsplit=str(line).translate(remap))
        if value != "":
            # log.info("string message=%s", value)
            producer_obj.produce(key=key, value=value, callback_method=delivery_report)
        else:
            log.error(f"could not convert data to avsc schema{line}")

    try:
        with open(file_name, "r+") as fin:
            file_name_list = fin.readlines()
    except IOError as e:
        log.error("filename=%s not exists or not accessible message=%s", file_name, str(e))
        sys.exit(-1)

    error_file_name = []
    for file in file_name_list:
        file = file.rstrip()
        log.info("retrieving file=%s from Mainframe and sending to kafka", file)

        try:
            producer_obj.create_producer(file)
            ftp_conn_obj.read_lines(file, call_back_method=send_lines_to_kafka)
            # need poll to call callback method
            producer_obj.poll(1)
        except (ConnectionError, error_perm, IOError) as e:
            if type(e) == ConnectionError:
                log.error(f"could not connect to topic error={e}")
            else:
                log.error(f"filename={file} not found error={e}")
            error_file_name.append(file)
            continue
        log.info("sent file=%s successfully", file)

    if not error_file_name:
        log.info("all files sent successfully")
    else:
        log.info(f"something wrong with {','.join(error_file_name)}")


if __name__ == '__main__':
    send()
