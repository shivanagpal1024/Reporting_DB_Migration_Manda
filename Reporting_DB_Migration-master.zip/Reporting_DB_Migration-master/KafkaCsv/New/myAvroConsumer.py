from confluent_kafka.avro import AvroConsumer
from confluent_kafka.avro.serializer import SerializerError


c = AvroConsumer({
    'bootstrap.servers': 'kaas-test-ctc-a.optum.com:443',
    'group.id': 'ecapgroup007',
    'schema.registry.url': 'http://kaas-test-schema-registry-a.optum.com'})

c.subscribe(['kaas.alpha.ecap.rpt_audit.test'])

while True:
    try:
        msg = c.poll(1)
    except SerializerError as e:
        print("Message deserialization failed for {}: {}".format(msg, e))
        break
    if msg is None:
        continue
    if msg.error():
        print("AvroConsumer error: {}".format(msg.error()))
        continue

    print(msg.value())

c.close()

