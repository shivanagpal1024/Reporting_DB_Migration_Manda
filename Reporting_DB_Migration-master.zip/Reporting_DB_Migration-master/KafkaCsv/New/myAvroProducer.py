from confluent_kafka.avro import AvroProducer
from confluent_kafka import avro
from collections import OrderedDict
import os
import json
from KafkaCsv.New import Constants as con


def delivery_report(err, msg):
    """ Called once for each message produced to indicate delivery result.
        Triggered by poll() or flush(). """
    if err is not None:
        print('Message delivery failed: {}'.format(err))
    else:
        print('Message delivered to {} [{}]'.format(msg.topic(), msg.partition()))


class MyAvroProducer:
    def __init__(self, configuration: dict):
        if not configuration:
            raise ValueError(f"config is empty or None {configuration}")

        self.__config: dict = configuration
        self.__producer: AvroProducer = None
        self.__key_schema, self.__value_schema, self.__table_name, self.__topic = None, None, None, None
        self.__default_values_dict = OrderedDict()
        self.__default_key_dict = OrderedDict()

    def get_default_values_dict(self) -> OrderedDict: return self.__default_values_dict

    def get_default_key_dict(self) -> OrderedDict: return self.__default_key_dict

    def create_producer(self, table_name: str):

        if not table_name or len(table_name.strip()) == 0:
            raise ValueError(f"incorrect table_name={table_name}")

        if table_name not in con.key_and_value_schema_dict:
            self.__table_name = self.__get_table_name(table_name)

        self.load_default_values(*con.key_and_value_schema_dict[self.__table_name])
        self.__topic = con.topic_map[self.__table_name]

        self.__value_schema, self.__key_schema = [avro.load(f"avsc{os.path.sep}{i}")
                                                  for i in con.key_and_value_schema_dict[self.__table_name]]

        self.__producer = AvroProducer(config=self.__config, default_key_schema=self.__key_schema,
                                       default_value_schema=self.__value_schema)

        return self.__producer

    def produce(self, key=None, value=None, callback_method=None):
        if self.__producer is None:
            raise NameError("producer is not created")

        if callback_method is None:
            callback_method = delivery_report

        self.__producer.produce(topic=self.__topic, key=key, value=value, callback=callback_method)
        self.__producer.poll(1)

    def poll(self, timeout) -> int: return self.__producer.poll(timeout)

    @staticmethod
    def __get_table_name(table_name: str):
        arr = table_name.split(".")
        if len(arr) > 2:
            return "_".join(string.lower() for string in arr[2:-1])
        raise IOError("tableName is not found")

    @staticmethod
    def __get_converted_value(i):
        val = i
        if i is not None and len(i) != 0:
            if i[0] == ',' and i[-1] == ',':
                val = i[1:-1]
            else:
                try:
                    val = int(i)
                except ValueError:
                    val = str(i)
        return val

    def get_avro_json(self, csv_row_unsplit: str, delimeter='|') -> (str, str):
        csv_row_array = csv_row_unsplit.split(delimeter)
        if len(csv_row_array) != len(self.__default_values_dict):
            return "", ""
        for i, k in zip(csv_row_array, self.__default_values_dict):
            if i is not None and len(i) != 0:
                val = self.__get_converted_value(i)
                self.__default_values_dict[k] = val
                if k in self.__default_key_dict:
                    self.__default_key_dict[k] = val
        # assuming schema is correct
        return self.__default_key_dict, self.__default_values_dict

    def load_default_values(self, value:str, key:str):
        if self.__default_values_dict:
            self.__default_values_dict.clear()

        if self.__default_key_dict:
            self.__default_key_dict.clear()

        with open(f"avsc{os.path.sep}{value}", "r") as f:
            val = json.load(f)

        for col in val['fields']:
            val = None
            type_in = col['type']
            if isinstance(type_in, list):
                if 'int' in type_in:
                    val = 0
                elif 'string' in type_in:
                    val = ''
            else:
                if 'int' == type_in:
                    val = 0
                elif 'string' == type_in:
                    val = ''
            self.__default_values_dict[col['name']] = val

        with open(f"avsc{os.path.sep}{key}", "r") as f:
            val = json.load(f)

        for col in val['fields']:
            val = col['name']
            self.__default_key_dict[val] = self.__default_values_dict[val]


if __name__ == '__main__':
    config = {
        "bootstrap.servers": 'localhost:9092',
        "schema.registry.url": "http://localhost:8081"
    }
    obj = MyAvroProducer(*config.values())

    pro = obj.create_producer("TSUO96Q.D6744DBP.RPT.AUDIT.UNLOAD")
    print(obj.get_default_values_dict())