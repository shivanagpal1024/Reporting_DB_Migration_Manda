from ftplib import FTP
from KafkaCsv.New import Constants as con


class FtpConn:
    def __init__(self, config_dict:dict = None, **kwargs):
        self.__host, self.__username, self.__password = None, None, None
        arr = [con.db2_host, con.db2_username, con.db2_password]

        if kwargs or config_dict:
            name = kwargs if kwargs else config_dict
            self.__host, self.__username, self.__password = [name[i] for i in arr]
        else:
            raise ValueError(f"config_dict={config_dict} or kwargs={kwargs} is empty")

        if not self.__host or not self.__username or not self.__password:
            raise ValueError(f"host={self.__host}, username={self.__username}, password={self.__password}")

        self.__ftp_conn = None
        self.__make_connection()

    def __make_connection(self) -> None:
        try:
            self.__ftp_conn = FTP(host=self.__host)
            self.__ftp_conn.login(user=self.__username, passwd=self.__password)
        except Exception as e:
            raise IOError("something went wrong while creating connection host=%s, username=%s, password=%s message=%s",
                          self.__host,
                          self.__username, self.__password, str(e))

    def read_lines(self, file_name = '', call_back_method=None) -> None:
        if file_name == '' or not file_name:
            raise ValueError("filename cannot be empty or nont")

        if not call_back_method:
            self.__ftp_conn.retrlines('RETR ' + f"'{file_name}'")
        else:
            self.__ftp_conn.retrlines('RETR ' + f"'{file_name}'", call_back_method)


if __name__ == '__main__':
    obj = FtpConn(db2_host="uhc2t1ip.uhc.com", db2_password="jan@1jan", db2_username="tsuo96q")
    obj.read_lines("TSUO96Q.D6744DBP.RPT.AUDIT.UNLOAD")