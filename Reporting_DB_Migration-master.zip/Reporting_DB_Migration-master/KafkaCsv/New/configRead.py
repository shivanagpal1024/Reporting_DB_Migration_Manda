import configparser as cp
import os


class ConfigRead:
    def __init__(self, file_name=None):
        self.__config_dict = {}
        self.__config = cp.ConfigParser()
        self.__read(file_name)

    def __read(self, file_name:str):
        if not file_name or file_name == '' or not os.path.exists(file_name):
            raise ValueError("configuration property file should be present")

        self.__config.read(file_name)
        error_list = []

        for key, value in self.__config['config'].items():
            if value is None or value.strip() == '':
                error_list.append(f'{key} \"{value}\" not found or incorrect\n')
            else:
                self.__config_dict[key] = value

        if error_list:
            raise ValueError(f"something went wrong while reading configuration={error_list}")

    def get_config_dict(self):
        return self.__config_dict


if __name__ == '__main__':
    obj = ConfigRead("kafka_config.properties")
    print(obj.get_config_dict())