package com.optum.ecap.factory;

import java.io.FileInputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.HashMap;
import java.util.Map;
import java.util.Properties;

import org.apache.kafka.clients.CommonClientConfigs;
import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerConfig;
import org.apache.kafka.clients.producer.ProducerConfig;
import org.apache.kafka.common.config.SslConfigs;
import org.apache.kafka.common.serialization.StringDeserializer;
import org.springframework.context.annotation.Bean;
import org.springframework.context.annotation.Configuration;
import org.springframework.kafka.annotation.EnableKafka;
import org.springframework.kafka.config.ConcurrentKafkaListenerContainerFactory;
import org.springframework.kafka.core.ConsumerFactory;
import org.springframework.kafka.core.DefaultKafkaConsumerFactory;

import com.optum.ecap.RptCtl.ReportControl;

import io.confluent.kafka.serializers.KafkaAvroDeserializer;
import io.confluent.kafka.serializers.KafkaAvroDeserializerConfig;

@EnableKafka
@Configuration
public class KafkaConfiguration {

	
		@Bean
		public ConsumerFactory<String,ReportControl> consumerFactory(){
		
			
			Properties SSL = new Properties();
		    InputStream input = null;
			try {
					ClassLoader loader = KafkaConfiguration.class.getClassLoader();
					input = new FileInputStream(loader.getResource("client-ssl.properties").getFile());
					SSL.load(input);
			
				} 
			catch (IOException ex)
				{
					ex.printStackTrace();
				} 
	 Map<String, Object> props = new HashMap<String, Object>();
	 // add property to disable auto-commit and add a line in the end of the process to commit the message to avoid message loss during sudden failures.
	 props.put(ProducerConfig.BOOTSTRAP_SERVERS_CONFIG,SSL.getProperty("kafka.bootstrap.servers"));
	 props.put(ConsumerConfig.GROUP_ID_CONFIG,SSL.getProperty("groupid.info"));
	 props.put(CommonClientConfigs.SECURITY_PROTOCOL_CONFIG,SSL.getProperty("security.protocol"));
	 props.put(SslConfigs.SSL_TRUSTSTORE_LOCATION_CONFIG,SSL.getProperty("ssl.truststore.location"));
	 props.put(SslConfigs.SSL_TRUSTSTORE_PASSWORD_CONFIG,SSL.getProperty("ssl.truststore.password"));
	 props.put(SslConfigs.SSL_KEYSTORE_LOCATION_CONFIG,SSL.getProperty("ssl.keystore.location"));
	 props.put(SslConfigs.SSL_KEYSTORE_PASSWORD_CONFIG,SSL.getProperty("ssl.keystore.password"));
	 props.put(SslConfigs.SSL_KEY_PASSWORD_CONFIG,SSL.getProperty("ssl.key.password"));
	 props.put("key.deserializer", StringDeserializer.class.getName());
	 props.put(KafkaAvroDeserializerConfig.SPECIFIC_AVRO_READER_CONFIG, true); 
	 props.put("value.deserializer", StringDeserializer.class.getName());
	 props.put("schema.registry.url", "http://cp-schema-registry-data-exts-platform-dev.ocp-ctc-core-nonprod.optum.com");
			
			return new DefaultKafkaConsumerFactory<String,ReportControl>(props);
		}
		
		@Bean
		public ConcurrentKafkaListenerContainerFactory<String,ReportControl> kafkaListenerContainerFactory() {
			
			ConcurrentKafkaListenerContainerFactory<String,ReportControl> factory= new ConcurrentKafkaListenerContainerFactory<String,ReportControl>();
			factory.setConsumerFactory(consumerFactory());
			return factory;
		}
		
}
