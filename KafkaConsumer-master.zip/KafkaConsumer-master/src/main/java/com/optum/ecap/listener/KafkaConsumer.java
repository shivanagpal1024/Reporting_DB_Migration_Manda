package com.optum.ecap.listener;

import org.apache.kafka.clients.admin.NewTopic;
import org.apache.kafka.clients.consumer.ConsumerRecord;
import org.springframework.context.annotation.Bean;
import org.springframework.kafka.annotation.KafkaListener;
import org.springframework.stereotype.Service;

@Service
public class KafkaConsumer {
	

	/*
	 * @KafkaListener(topics= "kaas.ecap.ctc.cmd.premium.v1", groupId = "ecap1")
	 * public void consume(String Key,String Message) {
	 * System.out.println("Message : " + Message ); }
	 */
	
	 @KafkaListener(topics= "kaas.ecap.ctc.cmd.premium.v1", groupId = "ecap1")
	    public void handle(ConsumerRecord<?, ?> cr) {
	        System.out.println("Message: "+cr.key()+":"+cr.value());
	        System.out.printf("offset = %d", cr.offset());
	    }
}
